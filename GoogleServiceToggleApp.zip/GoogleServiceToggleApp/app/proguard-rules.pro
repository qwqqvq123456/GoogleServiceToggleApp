# Shizuku
-keep class com.github.termux.shizuku.** { *; }
-dontwarn com.github.termux.shizuku.**

# Google services
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.android.gms.**

# AndroidX
-keep class androidx.core.** { *; }
-keep class androidx.appcompat.** { *; }
-keep class androidx.constraintlayout.** { *; }

# Add project specific ProGuard rules here.