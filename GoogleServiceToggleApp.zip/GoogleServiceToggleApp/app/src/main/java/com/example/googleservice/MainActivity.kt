package com.example.googleservice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.example.googleservice.databinding.ActivityMainBinding

class MainActivity : ComponentActivity() {
    
    private lateinit var binding: ActivityMainBinding
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Use ViewBinding or setContentView
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupUI()
    }
    
    private fun setupUI() {
        binding.btnSetup.setOnClickListener {
            if (ShizukuUtil.hasPermission() && ShizukuUtil.isShizukuAlive()) {
                showStatus("Shizuku 权限已授予")
            } else {
                // Request Shizuku permission
                ShizukuUtil.requestPermission(this)
                showStatus("正在请求 Shizuku 权限...")
            }
        }
        
        // Check initial status
        checkShizukuStatus()
    }
    
    private fun checkShizukuStatus() {
        val statusText = when {
            ShizukuUtil.hasPermission() && ShizukuUtil.isShizukuAlive() -> {
                "状态: 已连接 (Ready)"
            }
            ShizukuUtil.isShizukuAlive() -> {
                "状态: 未授予权限"
            }
            else -> {
                "状态: 未运行"
            }
        }
        binding.statusText.text = statusText
    }
    
    private fun showStatus(message: String) {
        binding.statusText.text = message
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
    
    override fun onResume() {
        super.onResume()
        checkShizukuStatus()
    }
}