package com.example.googleservice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.util.Log

object NotificationHelper {
    
    private const val TAG = "NotificationHelper"
    const val CHANNEL_ID = "google_service_channel"
    const val NOTIFICATION_ID = 1001
    
    fun createNotification(context: Context, isEnabled: Boolean): Notification {
        val toggleIntent = Intent(context, GoogleServiceWidgetProvider::class.java).apply {
            action = GoogleServiceWidgetProvider.ACTION_TOGGLE
        }
        
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            9999,
            toggleIntent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            else
                PendingIntent.FLAG_UPDATE_CURRENT
        )
        
        val title = if (isEnabled) "Google 服务已开启" else "Google 服务已关闭"
        val text = if (isEnabled) "点击关闭服务" else "点击开启服务"
        
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createChannel(context)
            Notification.Builder(context, CHANNEL_ID)
        } else {
            Notification.Builder(context)
        }
        
        return builder
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setOngoing(isEnabled)
            .setAction(
                android.R.drawable.ic_menu_edit,
                if (isEnabled) "关闭" else "开启",
                pendingIntent
            )
            .setColor(Color.parseColor(if (isEnabled) "#4CAF50" else "#F44336"))
            .build()
    }
    
    @RequiresApi(Build.VERSION_CODES.O)
    private fun createChannel(context: Context) {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Google 服务控制",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "用于控制 Google 服务开关"
            lockscreenVisibility = Notification.VISIBILITY_PRIVATE
        }
        
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(channel)
    }
    
    fun updateNotification(context: Context, isEnabled: Boolean) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = createNotification(context, isEnabled)
        notificationManager.notify(NOTIFICATION_ID, notification)
    }
    
    fun cancelNotification(context: Context) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(NOTIFICATION_ID)
    }
}