package com.example.googleservice

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.PendingIntentCompat
import java.util.*

class GoogleServiceWidgetProvider : AppWidgetProvider() {
    
    companion object {
        const val ACTION_TOGGLE = "com.example.googleservice.TOGGLE_GOOGLE_SERVICE"
        const val PREFS_NAME = "GoogleServiceWidget"
        
        private val SERVICE_NAMES = listOf(
            "Google Play Services",
            "Google Play Music",
            "Google Play Films",
            "Google Backup",
            "Google Device Registration"
        )
        
        private val PACKAGE_NAMES = listOf(
            "com.google.android.gms",
            "com.google.android.music",
            "com.google.android.videos",
            "com.google.android.backuptransport",
            "com.google.android.gsf.login"
        )
    }
    
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        // Update all widgets
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }
    
    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        // Clean up preferences when widget is deleted
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
        for (appWidgetId in appWidgetIds) {
            editor.remove("serviceState_$appWidgetId")
            editor.remove("selectedService_$appWidgetId")
        }
        editor.apply()
    }
    
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        
        if (intent.action == ACTION_TOGGLE) {
            val appWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
            if (appWidgetId != -1) {
                toggleGoogleService(context, appWidgetId)
                AppWidgetManager.get(context).updateAppWidget(appWidgetId, 
                    createUpdateViews(context, appWidgetId))
            }
        }
    }
    
    private fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
        val views = createUpdateViews(context, appWidgetId)
        appWidgetManager.updateAppWidget(appWidgetId, views)
    }
    
    private fun createUpdateViews(context: Context, appWidgetId: Int): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_google_service)
        
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val isEnabled = prefs.getBoolean("serviceState_$appWidgetId", true)
        val serviceName = prefs.getString("selectedService_$appWidgetId", "Google 服务", null) ?: "Google 服务"
        
        // Set service name
        views.setTextViewText(R.id.tvServiceName, serviceName)
        
        // Set toggle state
        val toggleView = views.getView(R.id.toggleSwitch)
        toggleView.setBackgroundColor(
            context.getColor(if (isEnabled) R.color.toggle_on else R.color.toggle_off)
        )
        
        // Set click handler
        val toggleIntent = Intent(context, GoogleServiceWidgetProvider::class.java).apply {
            action = ACTION_TOGGLE
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        }
        
        val pendingIntent = PendingIntent.getBroadcast(
            context, 
            appWidgetId, 
            toggleIntent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                PendingIntent.FLAG_IMMUTABLE else 0
        )
        
        views.setOnClickPendingIntent(R.id.toggleSwitch, pendingIntent)
        
        return views
    }
    
    private fun toggleGoogleService(context: Context, appWidgetId: Int) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val currentState = prefs.getBoolean("serviceState_$appWidgetId", true)
        val isCurrentlyEnabled = currentState
        
        // Toggle the state
        val newState = !isCurrentlyEnabled
        
        val editor = prefs.edit()
        editor.putBoolean("serviceState_$appWidgetId", newState)
        editor.apply()
        
        // Use Shizuku to modify Google services
        if (ShizukuUtil.hasPermission()) {
            ShizukuUtil.toggleGoogleServices(context, newState, appWidgetId)
        } else {
            // Fallback: try to use shell commands through Shizuku
            // This requires Shizuku to be running with proper permissions
        }
    }
}