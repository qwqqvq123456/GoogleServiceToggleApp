package com.example.googleservice

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import com.github.termux.shizuku.Shizuku

object ShizukuUtil {
    
    private const val TAG = "ShizukuUtil"
    private const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001
    
    fun hasPermission(): Boolean {
        return try {
            val result = Shizuku.checkSelfPermission()
            Log.d(TAG, "Shizuku permission check result: $result")
            result == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            Log.e(TAG, "Shizuku permission check failed", e)
            false
        }
    }
    
    fun isShizukuAlive(): Boolean {
        return try {
            Shizuku.isAlive()
        } catch (e: Exception) {
            Log.e(TAG, "Shizuku isAlive check failed", e)
            false
        }
    }
    
    fun toggleGoogleServices(context: Context, enable: Boolean, appWidgetId: Int) {
        try {
            if (enable) {
                // Enable Google services
                enableGoogleServices(context)
                showToast(context, "Google 服务已开启")
            } else {
                // Disable Google services
                disableGoogleServices(context)
                showToast(context, "Google 服务已关闭")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle Google services", e)
            showToast(context, "操作失败: ${e.message}")
        }
    }
    
    private fun enableGoogleServices(context: Context) {
        // 在 vivo 手机上，通过 Shizuku 启用 Google 相关服务
        val commands = listOf(
            "pm enable com.google.android.gms",
            "pm enable com.google.android.gsf",
            "pm enable com.google.android.gsf.login",
            "pm enable com.google.android.music",
            "pm enable com.google.android.videos"
        )
        
        executeCommandsViaShizuku(commands, context)
    }
    
    private fun disableGoogleServices(context: Context) {
        // 在 vivo 手机上，通过 Shizuku 禁用 Google 相关服务
        val commands = listOf(
            "pm disable com.google.android.gms",
            "pm disable com.google.android.gsf",
            "pm disable com.google.android.gsf.login",
            "pm disable com.google.android.music",
            "pm disable com.google.android.videos"
        )
        
        executeCommandsViaShizuku(commands, context)
    }
    
    private fun executeCommandsViaShizuku(commands: List<String>, context: Context) {
        if (!hasPermission() || !isShizukuAlive()) {
            Log.w(TAG, "Shizuku not available or no permission")
            showToast(context, "请先授予 Shizuku 权限")
            return
        }
        
        // 执行第一个命令
        if (commands.isNotEmpty()) {
            val command = commands[0]
            Log.d(TAG, "Executing command: $command")
            
            Shizuku.su(command, 2, 60) { exitCode ->
                Log.d(TAG, "Command executed, exit code: $exitCode")
                if (exitCode == 0) {
                    Log.i(TAG, "Command successful: $command")
                } else {
                    Log.w(TAG, "Command failed with exit code: $exitCode")
                }
            }
        }
    }
    
    private fun showToast(context: Context, message: String) {
        android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
    }
    
    fun requestPermission(activity: androidx.activity.ComponentActivity) {
        try {
            Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to request Shizuku permission", e)
            showToast(activity, "请求权限失败: ${e.message}")
        }
    }
}