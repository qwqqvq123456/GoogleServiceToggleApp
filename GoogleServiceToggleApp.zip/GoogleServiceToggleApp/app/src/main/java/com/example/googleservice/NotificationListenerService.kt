package com.example.googleservice

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * 通知监听服务
 * 用于在 vivo 手机上接收来自主界面的通知
 */
class NotificationListenerService : NotificationListenerService() {
    
    companion object {
        private const val TAG = "GoogleServiceListener"
    }
    
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        Log.d(TAG, "Notification posted: ${sbn?.key}")
    }
    
    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        Log.d(TAG, "Notification removed: ${sbn?.key}")
    }
    
    override fun onNotificationChanged(sbn: StatusBarNotification?) {
        super.onNotificationChanged(sbn)
        // 可以在这里添加自定义逻辑
    }
}