package com.example.googleservice

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts

class WidgetConfigureActivity : Activity() {
    
    companion object {
        const val PREFS_NAME = "GoogleServiceWidget"
        const val DEFAULT_SERVICE_STATE = "google_services_enabled"
    }
    
    private lateinit var prefs: android.content.SharedPreferences
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Get widget ID
        val appWidgetId = intent?.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        
        // Check and request Shizuku permission
        if (!ShizukuUtil.hasPermission()) {
            requestShizukuPermission()
        }
        
        // Save initial state
        val editor = prefs.edit()
        editor.putInt("appWidgetId_$appWidgetId", appWidgetId)
        editor.putBoolean("serviceState_$appWidgetId", getServiceState())
        editor.apply()
        
        // Set result
        val resultValue = Intent()
        resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        setResult(RESULT_OK, resultValue)
        finish()
    }
    
    private fun requestShizukuPermission() {
        // For vivo phones, we need to handle Shizuku permission
        // Users need to grant permission via Shizuku's setup
        val intent = Intent("com.github.termux.shizuku.permission.GRANT")
        startActivityForResult(intent, 1001)
    }
    
    private fun getServiceState(): Boolean {
        // Check if Google services are enabled
        return try {
            val setting = Settings.Secure.getString(contentResolver, "packages_whitelist")
            setting != null && setting.contains("com.google.android.gms")
        } catch (e: Exception) {
            false
        }
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001) {
            // Handle Shizuku permission result
        }
    }
}